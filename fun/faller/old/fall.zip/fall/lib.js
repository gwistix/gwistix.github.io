function init()
{
	var IE4 = (document.all && !document.getElementById)? true : false;
	var W3C = (document.getElementById)? true : false;

	if (IE4)
	{
		character_div = document.all['char_div'];
	}
	else
	{
		character_div = document.getElementById('char_div');
	}
}



function DisplayKey(e) {
	if (e.keyCode) keycode=e.keyCode;
		else keycode=e.which;

	switch (keycode)	{
		case 52: move("left"); break;
		case 53: jump(); break;
		case 54: move("right"); break;
	}
	
	window.status = keycode;
}

//-	-	-	-	-	-	-	-	-	-	-	-Image Changer
drop = new Image;
drop.src = "fall.gif";

stand = new Image;
stand.src = "stand.gif";

run_left = new Image;
run_left.src = "run_left.gif";

run_right = new Image;
run_right.src = "run_right.gif";

jump = new Image;
jump.src = "jump.gif";

function chgImg(name, image) {
	if (document.images)
	{
	document[name].src = eval(image+".src");
	}
}


function gravityck() {
	gravity = prompt("Enter gravity strength\n(1 through 20)");
	if (gravity == "undefined") gravity = 12;
	if (gravity > 20) gravity = 20;
	if (gravity < 1) gravity = 1;
	gravity = ((gravity / 1.11) / 2);
}



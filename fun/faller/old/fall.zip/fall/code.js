var gravity;
var speed = 2;
var velocity = 0;
var counter = 0;

var chart = 50;
var charl = 400;

var id=window.setTimeout("fall();",speed);


function fall() {
	if (chart >= 507) {
		chart = 507;
		blankit();
		chgImg("guy", "stand");
		character_div.style.top=chart;
		return;
	}

	counter++;
	window.status = "The counter is now at " + counter;
	document.form1.input1.value = "The counter is now at " + counter;
	id=window.setTimeout("fall();",speed);

	gravforce = (10 - gravity);

	if (velocity < 1000) velocity++;
		velocity = (velocity / gravforce);
		chart += (velocity * counter);
	
	character_div.style.top=chart;
}

function blankit() {
	counter = 0;
	velocity = 0;
}

function move(lorr) {
	if (lorr == "left") {
	chgImg("guy", "run_left");
	charl -= 25;
	}
	if (lorr == "right") {
	chgImg("guy", "run_right");
	charl += 25;
	}

	character_div.style.left=charl;
}

function jump() {
	if (chart >= 507) {
		for (chart=499;chart>300;chart--) {
//INSERT WAIT TIMEOUT HERE
//			id2=setTimeout("wait();",10000);
			character_div.style.top=chart;
		}

//		chart -= 200;

		chgImg("guy", "drop");
		fall();
		character_div.style.top=chart;
	}
}



function wait() {
	alert("waiting");
}